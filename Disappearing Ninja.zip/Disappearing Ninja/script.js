$('img').click(function() {
    $(this).hide(400);
})

$('button').click(function() {
    $('img').show(400);
})